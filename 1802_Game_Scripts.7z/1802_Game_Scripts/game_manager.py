from player import *
from vector import *
from collision import *
from tilemap import *
from enemy_manager import EnemyManager
from bat_particles import BatParticle
class Game(object):
    def __init__(self, win_w, win_h):
        self.player = Player(200, 100)
        self.enemyManager = EnemyManager()
        self.tilemap = Tilemap("external/tilemapData01.txt", 0, 0, win_w, win_h)
        self.xBoundaries = [500, 1200]
        self.currentBoundaryIndex = 0
        self.batEmitters = []
        self.swampBackgroundSound = pygame.mixer.Sound("external/Swamp_Background_web.wav")
        self.monsterEchoSound = pygame.mixer.Sound("external/MONSTER_Echo.wav")
        self.monsterEchoSoundRate = random.uniform(2, 4)
        self.monsterEchoSoundTime = 0
        self.swampBackgroundSound.set_volume(0.05)
        self.swampBackgroundSoundRate = random.uniform(4, 7)
        self.swampBackgroundSoundTimer = self.swampBackgroundSoundRate
        self.monsterEchoSound.set_volume(0.03)
        # batEmittersLen = 0
        # spacing = (self.tilemap.tileWorldEndX - self.tilemap.camX) / batEmittersLen
        # for i in range(batEmittersLen):
        #     x = i * spacing + 400
        #     self.batEmitters.append(BatParticle(Vector2(x, 400)))

    def render(self, window):
        for batEmitter in self.batEmitters:
            batEmitter.show(window, self.tilemap.camX, self.tilemap.camY)
        self.tilemap.show(window)
        self.player.show(window, self.tilemap)
        self.enemyManager.showEnemies(window, self.tilemap)
        currentBoundary = self.xBoundaries[self.currentBoundaryIndex]
        boundary_screen_x, _ = world_to_screen(currentBoundary, 0, self.tilemap.camX, self.tilemap.camY)
        #pygame.draw.line(window, (0, 0, 0), (boundary_screen_x, 0), (boundary_screen_x, self.tilemap.camH), 1)
    def update(self, dt, key_pressed):
        dist = distance(self.player.nodes["hip"].pos.x, self.player.nodes["hip"].pos.y, self.enemyManager.tentacle_enemy.centerX, self.enemyManager.tentacle_enemy.centerY)
        if dist <= 10000:
            self.monsterEchoSoundTime += dt
            if self.monsterEchoSoundTime >= self.monsterEchoSoundRate:
                self.monsterEchoSoundRate = random.uniform(2, 4)
                self.monsterEchoSoundTime = 0
                #self.monsterEchoSound.play()
        self.swampBackgroundSoundTimer += dt
        if self.swampBackgroundSoundTimer >= self.swampBackgroundSoundRate:
            self.swampBackgroundSoundTimer = 0
            self.swampBackgroundSoundRate = random.uniform(4, 7)
            self.swampBackgroundSound.play()
        for batEmitter in self.batEmitters:
            batEmitter.update(dt)
        self.player.update(dt, self.tilemap, self.tilemap.camX, self.tilemap.camY,
                           self.tilemap.camW, self.tilemap.camH, self.enemyManager.tentacle_enemy)
        self.enemyManager.updateEnemies(dt, self.tilemap, self.player)
        self.player.move(key_pressed)
        self.tilemap.adjust(self.player, dt)

    def mouseEvent(self, right, mouseX, mouseY):
        if right:
            self.player.fixed = True
            self.player.follow(mouseX, mouseY, self.tilemap.camX, self.tilemap.camY)
        else:
            self.player.fixed = False

    def handle_events(self, event, left, right):
        quitGame = False
        if event.type == pygame.QUIT:
            quitGame = True
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                quitGame = True
            elif event.key == pygame.K_SPACE:
                self.player.jump(self.tilemap)
        elif event.type == pygame.MOUSEBUTTONDOWN:

            if left and right:
                self.player.shoot()
                self.fixed = False

        return quitGame