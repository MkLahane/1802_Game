import pygame
import time

pygame.init()
win_w = 800
win_h = 600
win = pygame.display.set_mode((win_w, win_h))
ICE = (0, 0, 0)



menu = pygame.image.load("external/menu.png")
fontObj = pygame.font.SysFont("Courier New", 30)
menu_press = pygame.mixer.Sound('external/Menu-Button.wav')
menu_change = pygame.mixer.Sound('external/Menu_Change.wav')
done = False
y = 90
cooldown = 0
while True:
    pygame.event.pump()
    keys = pygame.key.get_pressed()
    if keys[pygame.K_ESCAPE]:
        break

    if cooldown > 0:
        cooldown -= 1
    if keys[pygame.K_DOWN]:
        if cooldown == 0:
            pygame.mixer.Sound.play(menu_change)
            cooldown = 10
            y += 100
    if y > 490:
        y = 490
    if keys[pygame.K_UP]:
        if cooldown == 0:
            pygame.mixer.Sound.play(menu_change)
            cooldown = 10
            y -= 100
    if y == 90:
        if keys[pygame.K_RETURN]:
            pygame.mixer.Sound.play(menu_press)
            time.sleep(.25)
            import main
    if y == 190:
        if keys[pygame.K_RETURN]:
            pygame.mixer.Sound.play(menu_press)
            time.sleep(.25)
            pygame.quit()
    if y == 290:
        if keys[pygame.K_RETURN]:
            pygame.mixer.Sound.play(menu_press)
            time.sleep(.25)
            pygame.quit()
    if y == 390:
        if keys[pygame.K_RETURN]:
            pygame.mixer.Sound.play(menu_press)
            time.sleep(.25)
            pygame.quit()
    if y == 490:
        if keys[pygame.K_RETURN]:
            pygame.mixer.Sound.play(menu_press)
            time.sleep(.25)
            pygame.quit()
    if y <= 90:
        y = 90

        # win.fill((0,0,0))
    win.blit(menu, (0, 0))
    pygame.draw.rect(win, (0, 0, 225), (290, y, 510, 70))
    pygame.draw.rect(win, ICE, (300, 100, 500, 50))  # cup # Rect(left, top, width, height)
    pygame.draw.rect(win, ICE, (300, 200, 500, 50))
    pygame.draw.rect(win, ICE, (300, 300, 500, 50))
    pygame.draw.rect(win, ICE, (300, 400, 500, 50))
    pygame.draw.rect(win, ICE, (300, 500, 500, 50))

    temp_surf = fontObj.render("NEW GAME", False, (255, 255, 255))
    win.blit(temp_surf, (500, 110))
    temp_surf = fontObj.render("LOAD GAME", False, (255, 255, 255))
    win.blit(temp_surf, (500, 210))
    temp_surf = fontObj.render("SETTINGS", False, (255, 255, 255))
    win.blit(temp_surf, (500, 310))
    temp_surf = fontObj.render("CREDITS", False, (255, 255, 255))
    win.blit(temp_surf, (500, 410))
    temp_surf = fontObj.render("QUIT", False, (255, 255, 255))
    win.blit(temp_surf, (500, 510))
    pygame.display.flip()


pygame.quit()

