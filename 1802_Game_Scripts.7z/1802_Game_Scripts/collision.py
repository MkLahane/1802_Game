def circleInRect(cx, cy, r, rx, ry, w, h):
    edgeX = cx
    edgeY = cy


    if cy < ry: #top edge
        edgeY = ry

    elif cy > ry + h: #bottom edge
        edgeY = ry + h

    if cx < rx: #left edge
        edgeX = rx

    elif cx > rx + w: #right edge
        edgeX = rx + w


    distFromEdge = distance(cx, cy, edgeX, edgeY)
    return distFromEdge <= r 


def distance(x1, y1, x2, y2):
    xdiff = x2 - x1
    ydiff = y2 - y1
    return (xdiff ** 2 + ydiff ** 2) ** 0.5