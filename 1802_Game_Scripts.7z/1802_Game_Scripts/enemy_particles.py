import pygame
from vector import *
from util import *
import random
from smokeParticles import *
from emitter import *
from collision import *
import pygame.gfxdraw
class EnemyParticle(object):
    def __init__(self, sx, sy, centerX, centerY, w, h, r, released = False, smokeColor = (0, 200, 150, 200), hide = False, lifetime = None, particle_lifetime = None, damage = 10):
        self.pos = Vector2(sx, sy)
        self.vel = polar_to_Vector2(random.randint(0, 360), 1) *  300
        self.acc = Vector2(0, 0)
        self.r = r
        self.w =  w
        self.h = h
        self.smokeColor = smokeColor
        self.hide = hide
        self.centerX = centerX
        self.centerY = centerY
        self.smokeEmitter = Emitter()
        self.released = released
        self.dead = False
        self.lifetime = lifetime
        self.damage = damage
        self.particle_lifetime = particle_lifetime
    def show(self, window, screenX, screenY):

        x, y = world_to_screen(self.pos.x, self.pos.y, screenX, screenY)
        if not self.hide:
            # if self.released:
            #     pygame.gfxdraw.filled_circle(window, int(x), int(y),
            #                                  int(self.r * 0.5), (0, 200, 150, 200))
            # else:
            pygame.draw.circle(window, (0, 0, 0), (int(x), int(y)), self.r)

        self.smokeEmitter.renderParticles(window, screenX, screenY)
    def update(self, dt, tilemap, player):

        if self.lifetime != None:
            self.lifetime -= dt
            if self.lifetime <= 0:
                self.dead = True
        if self.released and not self.dead:
            particle_pos = self.pos + self.vel.copy().normalize() * self.r
            particle_speed = random.randint(50, 100)
            particle_angle = self.vel.degrees()
            particle_color = self.smokeColor
            particle_size = random.randint(self.r // 2, self.r)   #random.randint(5, 10)
            particle_lifetime = random.randint(2, 3)
            if self.particle_lifetime != None:
                particle_lifetime = self.particle_lifetime

            for i in range(1):
                self.smokeEmitter.emit(SmokeParticle(particle_pos.x, particle_pos.y,
                                                 particle_speed, particle_angle,
                                                 particle_color, particle_size, 
                                                 particle_lifetime))
        self.vel += self.acc * dt
        self.pos += self.vel * dt
        self.acc *= 0
        self.smokeEmitter.updateParticles(dt)
        if not self.released:
            return
        x_screen, y_screen = world_to_screen(self.pos.x, self.pos.y, tilemap.camX, tilemap.camY)

        row = int(self.pos.y // tilemap.tileHeight)
        col = int(self.pos.x // tilemap.tileWidth)
        minRow = max(0, row - 3)
        minCol = max(0, col - 3)
        maxRow = min(tilemap.rows - 1, row + 4)
        maxCol = min(tilemap.cols - 1, col + 4)
        for i in range(minRow, maxRow):
            for j in range(minCol, maxCol):
                if tilemap.tiles[i][j].empty:
                    continue
                rx = tilemap.tiles[i][j].x
                ry = tilemap.tiles[i][j].y
                rw = tilemap.tileWidth
                rh = tilemap.tileHeight
                cx = self.pos.x
                cy = self.pos.y
                cr = self.r
                if circleInRect(cx, cy, cr, rx, ry, rw, rh):
                    self.dead = True
        if player.dead:
            return
        for nodeName in player.nodeNames:
            node = player.nodes[nodeName]
            dist = distance(node.pos.x, node.pos.y, self.pos.x, self.pos.y)
            if dist <= node.r + self.r:
                self.dead = True
                player.takeDamage(self.damage)
                force_dir = self.vel.copy().normalize() * 400
                if self.damage == 10:
                    player.addForces(force_dir.x, force_dir.y)
                if tilemap.camX <= 0:
                    tilemap.camX = 0
                elif tilemap.camX >= (tilemap.tileWorldEndX - tilemap.camW):
                    tilemap.camX = (tilemap.tileWorldEndX - tilemap.camW)

    def applyForce(self, f):
        self.acc += f
    def checkBounds(self, screenX, screenY, screenW, screenH):
        if not self.released:
            if self.pos.x < (self.centerX - self.w * 0.5) + self.r:
                self.pos.x = (self.centerX - self.w * 0.5) + self.r
                self.vel.x *= -1
            elif self.pos.x > (self.centerX + self.w * 0.5) - self.r:
                self.pos.x = (self.centerX + self.w * 0.5) - self.r
                self.vel.x *= -1
            if self.pos.y < (self.centerY - self.h * 0.5) + self.r:
                self.pos.y = (self.centerY - self.h * 0.5) + self.r
                self.vel.y *= -1
            elif self.pos.y > (self.centerY + self.h * 0.5) - self.r:
                self.pos.y = (self.centerY + self.h * 0.5) - self.r
                self.vel.y *= -1
        else:
            sx, sy = world_to_screen(self.pos.x, self.pos.y, screenX, screenY)
            return (sx < 0 or sy < 0 or sx > screenW or sy > screenH)



