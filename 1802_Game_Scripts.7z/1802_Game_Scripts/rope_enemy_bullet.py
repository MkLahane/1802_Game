from util import *
from collision import *
from vector import *
import pygame
import random
from smokeParticles import SmokeParticle
from emitter import Emitter
class RopeEnemyBullet(object):
    def __init__(self, pos, vel, r):
        self.pos = pos
        self.vel = vel
        self.acc = Vector2(0, 0)
        self.r = r
        self.smokeEmitter = Emitter()

    def show(self, window, screenX, screenY):
        x, y = world_to_screen(self.pos.x, self.pos.y, screenX, screenY)
        pygame.gfxdraw.filled_circle(window, int(x), int(y),
                                     int(self.r), (0, 0, 0, 200))
        num_circles = 50
        for i in range(num_circles):
            percent = i / num_circles
            col = int(percent * 255)
            r = self.r  - self.r * percent
            pygame.gfxdraw.filled_circle(window, int(x), int(y),
                                         int(r), (col, col, col, 200))
        self.smokeEmitter.renderParticles(window, screenX, screenY)

    def addForce(self, f):
        self.acc += f
    def update(self, dt):
        self.vel += self.acc * dt
        self.pos += self.vel * dt
        self.acc *= 0
        self.smokeEmitter.updateParticles(dt)
        particle_x = self.pos.x
        particle_y = self.pos.y
        particle_speed = random.uniform(50, 100)
        particle_size = random.uniform(2, 5)
        particle_angle = 0
        particle_color = (0, 0, 0, 255)
        particle_lifetime = random.uniform(1, 2)
        self.smokeEmitter.emit(SmokeParticle(particle_x, particle_y,
                                             particle_speed, particle_angle,
                                             particle_color, particle_size,
                                             particle_lifetime))


    def hit(self, player, tilemap):
        x, y = world_to_screen(self.pos.x, self.pos.y, tilemap.camX, tilemap.camY)
        if x < 0 or y < 0 or y > tilemap.camH or x > tilemap.camW:
            return True
        row = int(self.pos.y // tilemap.tileHeight)
        col = int(self.pos.x // tilemap.tileWidth)
        minRow = max(0, row - 3)
        minCol = max(0, col - 3)
        maxRow = min(tilemap.rows - 1, row + 4)
        maxCol = min(tilemap.cols - 1, col + 4)
        for i in range(minRow, maxRow):
            for j in range(minCol, maxCol):
                if tilemap.tiles[i][j].empty:
                    continue
                rx = tilemap.tiles[i][j].x
                ry = tilemap.tiles[i][j].y
                rw = tilemap.tileWidth
                rh = tilemap.tileHeight
                cx = self.pos.x
                cy = self.pos.y
                cr = self.r
                if circleInRect(cx, cy, cr, rx, ry, rw, rh):
                    return True
        if player.dead:
            return False

        for nodeName in player.nodeNames:
            node = player.nodes[nodeName]
            dist = distance(self.pos.x, self.pos.y, node.pos.x, node.pos.y)
            if dist <= node.r + self.r:
                player.takeDamage(10)
                return True

        return False