import pygame
from util import *
import random
class Tilemap(object):
    def __init__(self, tilemapFileName, camX, camY, camW, camH):
        self.tilemapFileName = tilemapFileName
        f = open(self.tilemapFileName, 'r')
        tilemapFileLines = f.readlines()
        f.close()
        self.player_window_width = 300
        self.player_window_height = 200
        self.rows = int(tilemapFileLines[1].split(':')[1])
        self.cols = int(tilemapFileLines[2].split(':')[1])

        self.tileWidth = float(tilemapFileLines[3].split(':')[1])
        self.tileHeight = float(tilemapFileLines[4].split(':')[1])
        self.tiles = [None] * self.rows
        for i in range(self.rows):
            self.tiles[i] = [None] * self.cols

        r = 0
        c = 0
        for i in range(5, len(tilemapFileLines)):
            empty = True
            tileData = tilemapFileLines[i]
            tileDataImg = tileData.split(";")[1]
            x = c * self.tileWidth
            y = r * self.tileHeight

            tileDataImg = tileDataImg[0: len(tileDataImg) - 1]
            if tileDataImg == "platform.png":
                empty = False

            self.tiles[r][c] = Tile(pygame.image.load('external/' + tileDataImg), x, y, self.tileWidth, self.tileHeight, empty)
            c += 1
            if c == self.cols:
                r += 1
                c = 0
        self.camX = camX
        self.camY = camY
        self.camW = camW
        self.camH = camH
        self.tileWorldEndX = (self.cols - 1) * self.tileWidth
        self.tileWorldEndY = (self.rows - 1) * self.tileHeight

        for i in range(self.rows):
            self.tiles[i][0].empty = False
            self.tiles[i][self.cols - 2].empty = False

    def getMinMaxRowCol(self):
        minRow = int(self.camY // self.tileHeight)
        if minRow < 0:
            minRow = 0
        minCol = int(self.camY // self.tileWidth)
        if minCol < 0:
            minCol = 0
        maxRow = int((self.camY + self.camH) // self.tileHeight)
        if maxRow >= self.rows:
            maxRow = self.rows - 1
        maxCol = int((self.camX + self.camW) // self.tileWidth) + 3
        if maxCol >= self.cols:
            maxCol = self.cols - 1
        return (minRow, minCol, maxRow, maxCol)

    def show(self, window):

        minRow, minCol, maxRow, maxCol = self.getMinMaxRowCol()

        for i in range(minRow, maxRow + 1):
            for j in range(minCol, maxCol + 1):
                y = int(i * self.tileHeight) - self.camY
                x = int(j * self.tileWidth) - self.camX
                self.tiles[i][j].show(self.camX, self.camY, window)
                if not self.tiles[i][j].empty:
                    if i != 0:
                        if self.tiles[i - 1][j].empty:
                            pygame.draw.line(window, (100, 100, 100), (int(x), int(y)),
                                             (int(x + self.tileWidth), int(y)), 10)


                #pygame.draw.rect(window, (0, 200, 0), (x, y, self.tileWidth, self.tileHeight), 2)

        x = self.camX + self.player_window_width
        y = self.camY + self.player_window_height
        camEndX = self.camX + self.camW
        camEndY = self.camY + self.camH
        w = (camEndX - self.player_window_width * 2) - x
        h = (camEndY - self.player_window_height * 2) - y
        x, y = world_to_screen(x, y, self.camX, self.camY)
        #pygame.draw.rect(window, (0, 0, 0), (x, y, w, h), 1)

    def adjust(self, player, dt):
        dy = 0 - self.camY
        self.camY += dy * 0.3
        if player.dead:
            return
        playerHipNode = player.nodes["hip"]
        bx = self.camX + self.player_window_width
        by = self.camY + self.player_window_height
        camEndX = self.camX + self.camW
        camEndY = self.camY + self.camH
        w = (camEndX - self.player_window_width * 2) - bx
        h = (camEndY - self.player_window_height * 2) - by
        speedFactor = 0.1
        # soft-slaved camera follow
        dx = (playerHipNode.pos.x - self.camW * 0.2) - self.camX
        if player.healthAlpha < 255 and player.healthAlpha != 0:
            dx += random.randint(-50, 50)
        tempCamX = self.camX + dx * speedFactor
        self.camY += dy * speedFactor
        if int((tempCamX + self.camW) // self.tileWidth) < self.cols:
            self.camX = tempCamX









class Tile(object):
    def __init__(self, tileImg, x, y, w, h, empty):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.tileImg = tileImg
        self.empty = empty

    def show(self, screenX, screenY, window):
        if self.empty:
            return
        x, y = world_to_screen(self.x, self.y, screenX, screenY)
        window.blit(self.tileImg, (x, y, self.w, self.h))





