# ETGG1803
# Basic Matrix class

from vector import *

class Matrix(object):
    """ A general purpose r x c matrix class """

    str_precision = None        # Round to this many decimal places
                                # when using the __str__ method


    def __init__(self, rows, cols, values = None):
        """
        Initialises a new matrix
        :param rows: A positive integer number of rows in the new matrix
        :param cols: A positive integer number of columns in the new matrix
        :param data: An optional parameter. If None, the matrix is initialised
                        to be all zeros. If a list or tuple of values of the correct
                        dimension is passed, then the matrix is initialised to
                        contain these values, one row at a time.
        """

        self.rows = rows
        self.cols = cols
        self.data = []

        for i in range(rows):
            temp_row = (0.0, ) * cols
            self.data.append(Vector(*temp_row))
        if values != None:
            if len(values) != rows * cols:
                raise ValueError(f"You must pass {rows * cols} values to create a Matrix with \
                                 {rows} rows and {cols} columns.")
            pos = 0
            for i in range(rows):
                for j in range(cols):
                    self.data[i][j] = float(values[pos])
                    pos += 1

    def __str__(self):
        """
        :return: A string version of this matrix.
        """
        result = "" 
        # Replace this so the matrix output looks like
        # /1.0    0.0    0.0    0.0\
        # |0.0    1.0    0.0    0.0|
        # |0.0    0.0    1.0    0.0|
        # \0.0    0.0    0.0    1.0/
        # but with the correct data values.
        for i in range(self.rows):
            if i == 0:
                s = "/"
            elif i == self.rows - 1:
                s = "\\" 
            else:
                s = "|"
            for j in range(self.cols):
                s = s + str(self.data[i][j])
                if j != self.cols - 1:
                    s += "\t" 

            if i == 0:
                s += '\\'
            elif i == self.rows - 1:
                s += '/' 
            else:
                s += '|' 
            result += s
            if i != self.rows - 1:
                result += "\n"
        return result 
        

    def __getitem__(self, index):
        """
        :param index: A tuple (row, col) where 0 <= row <= self.rows and 0 <= col <= self.cols
        :return: The float value at that position in the Matrix
        """
        if not isinstance(index, tuple) or len(index) != 2:
            raise IndexError("Indexing must be in the format M[row, col]")
        r = index[0]
        c = index[1]
        return self.data[r][c]

    def __setitem__(self, index, value):
        """
        :param index: A tuple (row, col) where 0 <= row <= self.rows and 0 <= col <= self.cols
        :param value: The new value to set at that position, to be converted to a float internally
        :return: None
        """
        if not isinstance(index, tuple) or len(index) != 2:
            raise IndexError("Indexing must be in the format M[row, col]")
        r = index[0]
        c = index[1]
        self.data[r][c] = value 


    def __add__(self, other):
        """
        :param other: A Matrix of the same dimension as self
        :return: The matrix sum of self and other
        """
        if not isinstance(other, Matrix) or self.rows != other.rows or self.cols != other.cols:
            raise TypeError("We can only add another Matrix of the same dimension.")
        matrix_sum = Matrix(self.rows, self.cols)
        for i in range(self.rows):
            for j in range(self.cols):
                matrix_sum[i, j] = self[i, j] + other[i, j] 
            
        return matrix_sum

    def get_row(self, row_number):
        """
        :param row_number: A row number with 0 <= row_number < self.rows. Negatives work as usual in Python
        :return: A copy of the specified row of the matrix as a Vector of dimension self.cols.
        """

        if not isinstance(row_number, int):
            raise TypeError("The row number must be an integer.")
        if row_number >= self.rows:
            raise ValueError("The row number must not be greater than the number of rows indexed from 0.")
        # Insert one line here to find the correct row
        r = self.data[row_number]
        return Vector(*r)

    def get_col(self, col_number):
        """
        :param col_number: A column number with 0 <= col_number < self.cols. Negatives work as usual in Python
        :return: A copy of the specified column of the matrix as a Vector of dimension self.rows.
        """
        
        if not isinstance(col_number, int):
            raise TypeError("The column number must be an integer.")
        if col_number >= self.cols:
            raise ValueError("The column number must not be greater than the number of columns indexed from 0.")
        c = [0.0] * self.rows
        for i in range(self.rows):
            # Insert one line here to find the correct column
            c[i] = self[i, col_number] 
        return Vector(*c)
    
    def __mul__(self, other):
        """
        :param other: A scalar, a Vector of dimension self.cols thought of as a column vector,
                      or another Matrix with other.rows == self.cols
        :return: If other is a scalar or Matrix, the result will be a Matrix. If other is a
                      Vector, the result will be a Vector of dimension self.rows.
        """

        if isinstance(other, (int, float)):
            temp_matrix = Matrix(self.rows, self.cols)
            for i in range(self.rows):
                for j in range(self.cols):
                    temp_matrix[i, j] = self[i, j] * other
            return temp_matrix

        if isinstance(other, Matrix):
            if other.rows != self.cols:
                raise TypeError("The number of rows in the second matrix must match the number of columns in the first")
            temp_matrix = Matrix(self.rows, other.cols)
            for i in range(self.rows):
                for j in range(other.cols):
                    temp_matrix[i, j] = dot(self.get_row(i), other.get_col(j))
            return temp_matrix
        
        if isinstance(other, Vector):
            temp_vector = [0.0] * self.rows
            for i in range(self.rows):
                temp_vector[i] = dot(self.get_row(i), other)   
            return Vector(*temp_vector)

    def __sub__(self, other):

        # Add your code to calculate the difference of two matrices.
       return self + other * -1

    def __rmul__(self, other):
        # Add your code to make multiplication work correctly when the Matrix is on the right side of the operation
         
        if (other.dim != self.rows):
            return ValueError("Cannot multiply")
        newVec = [0.0] * self.cols
        for i in range(self.cols):
            newVec[i] = dot(self.get_col(i), other)
        return Vector(*newVec)



    
