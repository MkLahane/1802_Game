import pygame
from vector import *
class HealthBar(object):
    def __init__(self, pos, w, h):
        self.healthBarPos = pos
        self.w = w
        self.h = h
        self.maxWidth = self.w
        self.maxHealthBar = 100
        self.currentHealthBar = 100

    def update(self, currentHealthBar):
        self.currentHealthBar = currentHealthBar
        percent = self.currentHealthBar / self.maxHealthBar
        self.w = percent * self.maxWidth
    def show(self, window):
        alpha = self.currentHealthBar / self.maxHealthBar
        alpha = 255 * alpha
        if alpha <= 30:
            alpha = 30
        pygame.gfxdraw.box(window, (int(self.healthBarPos.x), int(self.healthBarPos.y),
                                    self.w, self.h), (255, 255, 255, alpha))