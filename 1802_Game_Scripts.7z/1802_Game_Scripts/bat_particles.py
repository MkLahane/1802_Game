from burstParticles import *
from vector import *
from emitter import *

class BatParticle(object):
    def __init__(self, pos):
        self.pos = pos
        self.burstEmitter = Emitter()
        self.emitRate = 1.0
        self.emitTime = 0.0
        
        a = 0
        num_particles = 100
        da = 360 / num_particles
        for i in range(num_particles):
            self.burstEmitter.emit(BurstParticle(
                self.pos.x, self.pos.y,
                random.randint(50, 100), a,
                (0, 0, 0, 255), random.randint(5, 10), 3
            ))
            a += da
    def show(self, window, screenX, screenY):
        self.burstEmitter.renderParticles(window, screenX, screenY)

    def update(self, dt):
        self.burstEmitter.updateParticles(dt)
        self.emitTime += dt
        if self.emitTime >= self.emitRate:
            self.emitTime = 0.0
            a = 0
            num_particles = 100
            da = 360 / num_particles
            for i in range(num_particles):
                self.burstEmitter.emit(BurstParticle(
                    self.pos.x, self.pos.y,
                    random.randint(50, 100), a,
                    (0, 0, 0, 255), random.randint(5, 10), 3
                ))
                a += da
