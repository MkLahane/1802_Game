import pygame
from vector import *
from collision import *
class Text(object):
    def __init__(self, x, y, normalColor, hoverColor):
        self.x = x
        self.y = y
        self.normalColor = normalColor
        self.hoverColor = hoverColor
        self.normalSize = 150
        self.hoverSize = 130
        self.text_font = pygame.font.Font('external/Shadows_Into_Light/ShadowsIntoLight-Regular.ttf', self.normalSize)
        self.w = 600
        self.h = 100
    def show(self, window, text_str, mouseX, mouseY):
        text_surf = self.text_font.render(text_str, False, self.normalColor)
        w = text_surf.get_width()
        h = text_surf.get_height()
        if self.isHovering(mouseX, mouseY):
            text_surf = self.text_font.render(text_str, False, self.hoverColor)
        window.blit(text_surf, (self.x, self.y))

    def isHovering(self, mouseX, mouseY):
        return (mouseX > self.x and mouseX < self.x + self.w and mouseY > (self.y + self.h) and mouseY < self.y + self.h * 2)

