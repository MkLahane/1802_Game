import pygame
import math
import random
from particle import Particle

class SmokeParticle(Particle):
    def __init__(self, x, y, speed, angle, initialColor, initialSize,
                 initialLifetime):
        super().__init__(x, y, speed, angle, initialColor, initialSize, initialLifetime)

    def update(self, dt):
        if self.lifetime > 0:
            # compute displacements
            dx = dt * self.speed * math.cos(math.radians(self.angle))
            dy = -1 * dt * self.speed * math.sin(math.radians(self.angle))
            # update the position
            self.x += dx
            self.y += dy
        else:
            self.dead = True
        self.size *= 1.03
        red, green, blue, alpha = self.color
        red *= 0.98
        green *= 0.99
        blue *= 0.97
        alpha *= 0.93
        if red > 255:
            red = 255
        if green > 255:
            green = 255
        if blue > 255:
            blue = 255
        self.speed *= 0.99
        self.color = (red, green, blue, alpha)
        self.lifetime -= dt