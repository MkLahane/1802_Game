import pygame
import pygame.gfxdraw
import math
import random

FRAME_RATE = 100
FRAME_DT = 1 / FRAME_RATE

class Dust_Particle(object):

    #To be done when the bullet collides with a wall

    def __init__(self, x, y, speed, angle, size, color, lifetime):
        self.x = x
        self.y = y
        self.speed = speed
        self.angle = angle
        self.size = size
        self.color = color
        self.lifetime = lifetime


    def update(self):
        dx = FRAME_DT * self.speed*math.cos(math.radians(self.angle))
        dy = -1 * FRAME_DT * self.speed * math.sin(math.radians(self.angle))
        self.x += dx
        self.y += dy
        self.lifetime -= FRAME_DT
        self.size *= 1.0
        self.speed *= 1.02
        red,green,blue,alpha = self.color
        red *= 0.97
        green *= 0.97
        blue *= 0.97
        alpha *= 0.97
        self.color = (red, green, blue, alpha)


    def render(self):
        pygame.gfxdraw.filled_circle(Screen_or_World, int(self.x), int(self.y), int(self.size), self.color)
class Dust_ParticleEmitter(object):
    def __init__(self, x, y, angle, speed):
        self.x = x
        self.y = y
        self.angle = angle
        self.speed = speed
        self.particleList = []

    def emit(self):
        angle = the bullets angle before it impacts - 180
        speed = 300
        size = 2
        color = (200, 200, 150, 255)
        lifetime = 0.25
        self.particleList.append(Dust_Particle(self.x, self.y, speed, angle, size, color, lifetime))

    def update(self):
        particlesToRemove = []
        for particle in self.particleList:
            particle.update()
            if particle.lifetime <= 0:
                particlesToRemove.append(particle)

        for particle in particlesToRemove:
            self.particleList.remove(particle)

    def render(self):
        for particle in self.particleList:
            particle.render()

class Shot_Particle(object):

    #To be done when the gun is shot

    def __init__(self, x, y, speed, angle, size, color, lifetime):
        self.x = x
        self.y = y
        self.speed = speed
        self.angle = angle
        self.size = size
        self.color = color
        self.lifetime = lifetime


    def update(self):
        dx = FRAME_DT * self.speed*math.cos(math.radians(self.angle))
        dy = -1 * FRAME_DT * self.speed * math.sin(math.radians(self.angle))
        self.x += dx
        self.y += dy
        self.lifetime -= FRAME_DT
        self.size *= 1.0
        self.speed *= 1.0
        red,green,blue,alpha = self.color
        red *= 0.8
        green *= 0.8
        blue *= 0.8
        alpha *= 1
        self.color = (red, green, blue, alpha)

    def render(self):
        #pygame.draw.circle(ds, self.color, (int(self.x), int(self.y)), self.size, 0)
        pygame.gfxdraw.filled_circle(screen_or_world, int(self.x), int(self.y), int(self.size), self.color)

class Shot_ParticleEmitter(object):
    def __init__(self, x, y, angle, speed):
        self.x = x #wherever the tip of the gun is
        self.y = y #wherever the tip of the gun is
        self.angle = angle
        self.speed = speed
        self.particleList = []

    def emit(self):
        angle = angle of the gun
        speed = 0
        size = 4
        color = (255,200,0,255)
        lifetime = 0.1
        self.particleList.append(Shot_Particle(self.x, self.y, speed, angle, size, color, lifetime))

    def update(self):
        particlesToRemove = []
        for particle in self.particleList:
            particle.update()
            if particle.lifetime <= 0:
                particlesToRemove.append(particle)

        for particle in particlesToRemove:
            self.particleList.remove(particle)

    def render(self):
        for particle in self.particleList:
            particle.render()


class Gun_Smoke_Particle(object):

    #To be done when the gun is shot

    def __init__(self, x, y, speed, angle, size, color, lifetime):
        self.x = x
        self.y = y
        self.speed = speed
        self.angle = angle
        self.size = size
        self.color = color
        self.lifetime = lifetime


    def update(self):
        dx = FRAME_DT * self.speed*math.cos(math.radians(self.angle))
        dy = -1 * FRAME_DT * self.speed * math.sin(math.radians(self.angle))
        self.x += dx
        self.y += dy
        self.lifetime -= FRAME_DT
        self.size *= 1.015
        self.speed *= 1.0
        red,green,blue,alpha = self.color
        red *= 0.97
        green *= 0.97
        blue *= 0.97
        alpha *= 1
        self.color = (red, green, blue, alpha)

    def render(self):
        #pygame.draw.circle(ds, self.color, (int(self.x), int(self.y)), self.size, 0)
        pygame.gfxdraw.filled_circle(screen_or_world, int(self.x), int(self.y), int(self.size), self.color)

class Gun_Smoke_ParticleEmitter(object):
    def __init__(self, x, y, angle, speed):
        self.x = x #wherever the tip of the gun is
        self.y = y #wherever the tip of the gun is
        self.angle = angle
        self.speed = speed
        self.particleList = []

    def emit(self):
        angle = random.uniform(80, 100)
        speed = 100
        size = 2
        color = (200,200,200,200)
        lifetime = 1
        self.particleList.append(Gun_Smoke_Particle(self.x, self.y, speed, angle, size, color, lifetime))

    def update(self):
        particlesToRemove = []
        for particle in self.particleList:
            particle.update()
            if particle.lifetime <= 0:
                particlesToRemove.append(particle)

        for particle in particlesToRemove:
            self.particleList.remove(particle)

    def render(self):
        for particle in self.particleList:
            particle.render()
