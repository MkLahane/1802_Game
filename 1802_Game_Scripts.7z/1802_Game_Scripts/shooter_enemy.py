from vector import *
from util import *
import pygame
from smokeParticles import SmokeParticle
from emitter import Emitter
import random
from enemy_particles import *
class ShooterEnemy(object):
    def __init__(self, x, y, w, h, num_particles):
        self.pos = Vector2(x, y)
        self.w = w
        self.h = h
        self.moveRate = 3
        self.move = True
        self.moveTimer = 0
        self.num_particles = num_particles
        self.enemyParticles = []
        #self.smokeEmitter = Emitter()
    def show(self, window, screenX, screenY, screenH):
        x, y = world_to_screen(self.pos.x, self.pos.y, screenX, screenY)
        #self.smokeEmitter.renderParticles(window, screenX, screenY)
        for enemy_particle in self.enemyParticles:
            enemy_particle.show(window, screenX, screenY)
        pygame.draw.rect(window, (0, 0, 0), (int(x), int(y), int(self.w), int(self.h)))

    def update(self, dt, tilemap, player):

        allDead = True
        for enemy_particle in self.enemyParticles:
            if not enemy_particle.dead:
                allDead = False
        if allDead:
            self.enemyParticles.clear()
        for enemy_particle in self.enemyParticles:
            enemy_particle.update(dt, tilemap, player)
        #self.smokeEmitter.updateParticles(dt)
        self.moveTimer += dt
        if self.moveTimer >= self.moveRate:
            self.move = True
            self.moveTimer = 0.0

        if self.move:

            spacing = self.w / self.num_particles
            for i in range(self.num_particles - 1):
                r = 15
                x = self.pos.x + i * spacing + r * 0.5
                self.enemyParticles.append(EnemyParticle(
                    x, self.pos.y, -1, -1, -1, -1, r, released = True, smokeColor = (0, 150, 200, 200), hide = True, lifetime = 2.0, particle_lifetime = 2.0, damage = 1
                ))
                self.enemyParticles[len(self.enemyParticles) - 1].vel = polar_to_Vector2(90, 300)

            self.move = False

