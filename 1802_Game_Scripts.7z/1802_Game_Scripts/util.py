def screen_to_world(x, y, screenX, screenY):
    return (x + screenX, y + screenY)

def world_to_screen(x, y, screenX, screenY):
    return (x - screenX, y - screenY)
