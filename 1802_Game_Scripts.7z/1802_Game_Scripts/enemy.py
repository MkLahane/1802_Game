from tentacle import *
from vector import *
import math
import random
from util import *
from emitter import Emitter
from enemy_particles import *
from burstParticles import BurstParticle
class Enemy(object):
    def __init__(self, numTentacles, sX, sY):
        self.numTentacles = numTentacles
        self.tentacles = []
        self.targets = []
        self.numSegments = 15
        self.enemyParticlesBurst = Emitter()
        a = 0
        da = 360 / self.numTentacles
        for i in range(self.numTentacles):
            self.tentacles.append(Tentacle(Vector2(sX, sY), math.radians(a), 15, self.numSegments))
            a += da
        self.enemyParticles = []
        self.centerX = sX
        self.centerY = sY
        self.w = 500
        self.h = 500
        self.dead = False
        self.health = 100
        for i in range(self.numTentacles):
            self.enemyParticles.append(EnemyParticle(random.uniform(self.centerX - self.w * 0.5 + 10, self.centerX + self.w * 0.5 - 10),
                                                    random.uniform(self.centerY - self.h * 0.5 + 10, self.centerY + self.h * 0.5 - 10),
                                                    self.centerX, self.centerY, self.w, self.h, 10))

        for enemyParticle in self.enemyParticles:
            self.targets.append(enemyParticle)
        self.timeToFire = 0.0
        self.fireRate = 1
        self.canFire = False
        self.discovered = False
        self.fireSound = pygame.mixer.Sound('external/playerShoot2.wav')
    def show(self, window, screenX, screenY):

        center_screenX, center_screenY = world_to_screen(self.centerX, self.centerY, screenX, screenY)
        pygame.gfxdraw.filled_circle(window, int(center_screenX), int(center_screenY),
                                     20, (0, 0, 0, 255))
        maxr = 20
        num_circles = 10
        for i in range(num_circles):
            percent = i / num_circles
            col = int(percent * 255)
            r = maxr - percent * maxr
            pygame.gfxdraw.filled_circle(window, int(center_screenX), int(center_screenY),
                                     int(r), (0, 200, 150, col))

        if not self.dead:
            self.enemyParticlesBurst.renderParticles(window, screenX, screenY)
            for enemyParticle in self.enemyParticles:
                enemyParticle.show(window, screenX, screenY)
            rx = int(self.centerX - self.w * 0.5)
            ry = int(self.centerY - self.h * 0.5)
            for tentacle in self.tentacles:
                tentacle.show(window, screenX, screenY)
            #pygame.draw.rect(window, (0, 0, 0), (int(rx), int(ry), self.w, self.h), 2)

    def update(self, dt, screenX, screenY, screenW, screenH, player, tilemap):
        if not self.dead:
            self.enemyParticlesBurst.updateParticles(dt)
            if not self.canFire:
                self.timeToFire += dt
                if self.timeToFire >= self.fireRate:
                    self.timeToFire = 0.0
                    self.canFire = True

            for enemyParticle in self.enemyParticles:
                enemyParticle.update(dt, tilemap, player)
                enemyParticle.checkBounds(screenX, screenY, screenW, screenH)
                if enemyParticle.dead:
                    a = 0
                    num_particles = 30
                    da = 360 / num_particles
                    for i in range(num_particles):
                        self.enemyParticlesBurst.emit( BurstParticle(
                            enemyParticle.pos.x, enemyParticle.pos.y,
                            random.randint(50, 100), a,
                            (0, 0, 0, 255), random.randint(2, 3), 1
                        ))
                        a += da
                    self.enemyParticles.remove(enemyParticle)
            for i in range(len(self.tentacles)):
                tentacle = self.tentacles[i]
                tentacle.lastFollow(self.targets[i].pos.x, self.targets[i].pos.y)
                tentacle.follow()
                tentacle.fix(self.centerX, self.centerY)


            if self.canFire:
                self.fire(player)

                self.canFire = False

    def fire(self, player):
        if player.dead:
            return
        dist = distance(player.nodes["hip"].pos.x, player.nodes["hip"].pos.y, self.centerX, self.centerY)
        if dist >= 1000 and not self.discovered:
            return
        self.discovered = True
        self.fireSound.play()
        rIndex = random.randint(0, len(self.targets) - 1)
        releasedParticle = self.targets[rIndex]
        releasedParticle.released = True
        dir = player.nodes["hip"].pos - releasedParticle.pos
        releasedParticle.r *= 2
        #releasedParticle.applyForce(dir.normalize() * 100)
        releasedParticle.vel = dir.normalize() * 300
        newEnemyParticle = EnemyParticle(random.uniform(self.centerX - self.w * 0.5 + 10, self.centerX + self.w * 0.5 - 10),
                                                    random.uniform(self.centerY - self.h * 0.5 + 10, self.centerY + self.h * 0.5 - 10),
                                                    self.centerX, self.centerY, self.w, self.h, 10)

        self.targets[rIndex] = newEnemyParticle
        self.enemyParticles.append(newEnemyParticle)

    def takeDamage(self, damage):
        self.health -= damage
        if self.health <= 0:
            self.dead = True
            self.health = 0

