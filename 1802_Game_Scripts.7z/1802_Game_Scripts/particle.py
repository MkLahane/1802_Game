import math
import pygame
import pygame.gfxdraw
from util import *



class Particle(object):
    def __init__(self, x, y, speed, angle, initialColor, initialSize,
                 initialLifetime):
        self.x = x
        self.y = y
        self.speed = speed
        self.angle = angle
        self.size = initialSize
        self.color = initialColor
        self.lifetime = initialLifetime
        self.dead = False

    def update(self, dt):

        if self.lifetime > 0:
            # compute displacements
            dx = dt * self.speed * math.cos(math.radians(self.angle))
            dy = -1 * dt * self.speed * math.sin(math.radians(self.angle))
            # update the position
            self.x += dx
            self.y += dy
        else:
            self.dead = True
        self.size += 1.03
        red, green, blue, alpha = self.color
        red *= 0.98
        green *= 1.0
        blue *= 0.99
        alpha *= 0.95
        self.speed *= 0.99
        self.color = (red, green, blue, alpha)
        self.lifetime -= dt

    def render(self, ds, screenX, screenY):
        x, y = world_to_screen(self.x, self.y, screenX, screenY)
        #pygame.draw.circle(ds, (self.color), (int(self.x), int(self.y)), int(self.size), 0)
        pygame.gfxdraw.filled_circle(ds, int(x), int(y),
                                     int(self.size), self.color)



