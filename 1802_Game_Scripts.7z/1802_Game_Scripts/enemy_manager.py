from util import *
import pygame
from collision import *
from vector import *
from enemy import Enemy
from shooter_enemy import ShooterEnemy
from rope_enemy import *
class EnemyManager(object):
    def __init__(self):
        self.tentacle_enemy = Enemy(20, 4000, 300)
        self.shooterEnemies = []
        self.shooterEnemies.append(ShooterEnemy(500, 750, 200, 50, 20))
        self.shooterEnemies.append(ShooterEnemy(1050, 750, 200, 50, 20))
        self.shooterEnemies.append(ShooterEnemy(2180, 750, 200, 50, 20))
        self.ropeEnemies = [RopeEnemy(400, 20), RopeEnemy(1000, 20), RopeEnemy(2200, 20), RopeEnemy(3500, 20)]
    def showEnemies(self, window, tilemap):
        for ropeEnemy in self.ropeEnemies:
            ropeEnemy.show(window, tilemap.camX, tilemap.camY)
        self.tentacle_enemy.show(window, tilemap.camX, tilemap.camY)
        # for shooterEnemy in self.shooterEnemies:
        #     shooterEnemy.show(window, tilemap.camX, tilemap.camY, tilemap.camH)

    def updateEnemies(self, dt, tilemap, player):
        for ropeEnemy in self.ropeEnemies:
            ropeEnemy.update(dt, player, tilemap)
        self.tentacle_enemy.update(dt, tilemap.camX, tilemap.camY, tilemap.camW, tilemap.camH, player, tilemap)
        # for shooterEnemy in self.shooterEnemies:
        #     shooterEnemy.update(dt, tilemap, player)