import pygame
from collision import distance
import math
from util import *
class Bone(object):
    def __init__(self, startNode, endNode, stiffness = 0.1):
        self.startNode = startNode
        self.endNode = endNode
        self.restingLen = distance(self.startNode.pos.x, self.startNode.pos.y, self.endNode.pos.x, self.endNode.pos.y)
        self.xdiff = abs(self.endNode.pos.x - self.startNode.pos.x)
        self.ydiff = abs(self.endNode.pos.y - self.startNode.pos.y)
        self.stiffness = stiffness
    def show(self, window, screenX, screenY, color = (255, 255, 255), nodeColor = (255, 255, 255)):
        s = self.startNode.pos
        e = self.endNode.pos
        sx, sy = world_to_screen(s.x, s.y, screenX, screenY)
        ex, ey = world_to_screen(e.x, e.y, screenX, screenY)
        pygame.draw.line(window, color, (int(sx), int(sy)), (int(ex), int(ey)), 4)
        self.startNode.show(window, screenX, screenY, nodeColor)
        self.endNode.show(window, screenX, screenY, nodeColor)

    def update(self, dt, tilemap):
        a = self.startNode.update(dt, tilemap)
        b = self.endNode.update(dt, tilemap)
        return a or b

    def stayUp(self, dt):
        ydiff = self.endNode.pos.y - self.startNode.pos.y
        if ydiff < self.ydiff:
            self.startNode.pos.y -= 0.5 * dt
    def constrain(self, dt, tilemap):

        # p1pos = self.startNode.pos
        #
        # p2pos = self.endNode.pos
        #
        # delta = p2pos - p1pos
        #
        # delta_length = delta.mag()
        #
        #
        # diff = (delta_length - self.restingLen) / (delta_length * (self.startNode.invmass + self.endNode.invmass))
        #
        # if not self.startNode.fixed:
        #     self.startNode.pos += delta.copy().normalize() * (0.5 * diff * self.startNode.invmass)
        # if not self.endNode.fixed:
        #     self.endNode.pos -= delta.copy().normalize() * (0.5 * diff * self.endNode.invmass)
        #
        #
        # self.startNode.update(dt, tilemap)
        # self.endNode.update(dt, tilemap)
        p1 = self.startNode.pos
        p2 = self.endNode.pos
        dx = p2.x - p1.x
        dy = p2.y - p1.y
        currentD = math.sqrt(dx * dx + dy * dy)
        diff = self.restingLen - currentD
        percentOff = diff / currentD
        percentOff /= 2
        offsetX = percentOff * dx * self.stiffness
        offsetY = percentOff * dy * self.stiffness
        if not self.startNode.fixed:
            p1.x -= offsetX
            p1.y -= offsetY

        self.startNode.pos = p1

        if not self.endNode.fixed:
            p2.x += offsetX
            p2.y += offsetY

        self.endNode.pos = p2
        self.startNode.update(dt, tilemap)
        self.endNode.update(dt, tilemap)


    def specialShow(self, window, screenX, screenY):
        sx, sy = world_to_screen(self.startNode.pos.x, self.startNode.pos.y, screenX, screenY)
        ex, ey = world_to_screen(self.endNode.pos.x, self.endNode.pos.y, screenX, screenY)
        pygame.draw.line(window, (50, 50, 50), (int(sx), int(sy)), (int(ex), int(ey)), 20)
        # self.startNode.show(window, screenX, screenY)
        # self.endNode.show(window, screenX, screenY)