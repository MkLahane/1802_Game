import tilemap
import pygame
from game_manager import Game
from uitext import *

pygame.init()
win_w = 1200
win_h = 800

background_sound = pygame.mixer.Sound("external/background2.wav")
window = pygame.display.set_mode((win_w, win_h))

clock = pygame.time.Clock()

game = Game(win_w, win_h)
background_image = pygame.image.load('external/game_background.png')
background_sound.play(-1)
paused = False
pausedRectAlpha = 100
newGameText = Text(500, 300, (50, 50, 50), (0, 0, 0))
quitGameText = Text(500, 500, (50, 50, 50), (0, 0, 0))
while True:
    window.fill((0, 0, 0))
    window.blit(background_image, (0, 0), (game.tilemap.camX, game.tilemap.camY, game.tilemap.camW, game.tilemap.camH))
    dt = clock.tick() / 1000

    event = pygame.event.poll()
    left, _, right = pygame.mouse.get_pressed()
    mouseX, mouseY = pygame.mouse.get_pos()
    if event.type == pygame.KEYDOWN:
        if event.key == pygame.K_p:
            paused = not paused
            pausedRectAlpha = 100
        elif event.key == pygame.K_ESCAPE:
            break
    elif event.type == pygame.QUIT:
        break
    elif event.type == pygame.MOUSEBUTTONDOWN:
        if paused:
            if left:
                if newGameText.isHovering(mouseX, mouseY):
                    game = Game(win_w, win_h)
                    background_sound.play(-1)
                    paused = False
                elif quitGameText.isHovering(mouseX, mouseY):
                    break

    game.render(window)
    if not paused:
        pausedRectAlpha -= dt * 0.5
        if pausedRectAlpha < 0:
            pausedRectAlpha = 0
        game.update(dt, pygame.key.get_pressed())
        game.mouseEvent(right, mouseX, mouseY)
        if game.handle_events(event, left, right):
            break
    if paused:
        pygame.gfxdraw.box(window, (0, 0,
                                    win_w, win_h), (255, 255, 255, pausedRectAlpha))
        newGameText.show(window, "New Game", mouseX, mouseY)
        quitGameText.show(window, "Quit Game", mouseX, mouseY)

    pygame.display.flip()

pygame.quit()