import pygame
from vector import *
import random
from util import *
from smokeParticles import SmokeParticle
from emitter import Emitter
from collision import *
class Bullet(object):
    def __init__(self, pos, angle, r):
        self.pos = pos
        speed = 700
        self.vel = polar_to_Vector2(angle, speed, mode = "radians")
        self.r = r
        self.acc = Vector2(0, 0)
        self.smokeEmitter = Emitter()
    def show(self, window, screenX, screenY):
        x, y = world_to_screen(self.pos.x, self.pos.y, screenX, screenY)
        pygame.draw.circle(window, (255, 255, 255), (int(x), int(y)), self.r)
        self.smokeEmitter.renderParticles(window, screenX, screenY)
    def update(self, dt):

        particle_pos = (self.vel.copy().normalize() * -self.r) + self.pos
        for i in range(2):
            self.smokeEmitter.emit(
                SmokeParticle(self.pos.x, self.pos.y, random.randint(30, 50),
                              random.randint(-100, -80), (255, 255, 255, 200), random.randint(3, 5),
                              0.1))
        self.smokeEmitter.updateParticles(dt)
        self.vel += self.acc * dt
        self.pos += self.vel * dt
        self.acc *= 0

    def out_of_bounds(self, screenX, screenY, w, h):
        x,y = world_to_screen(self.pos.x, self.pos.y, screenX, screenY)
        return (x < 0 or y < 0 or x > w or y > h)

    def applyForce(self, f):
        self.acc += f

    def hit(self, enemy, tilemap):
        row = int(self.pos.y // tilemap.tileHeight)
        col = int(self.pos.x // tilemap.tileWidth)
        minRow = max(0, row - 3)
        minCol = max(0, col - 3)
        maxRow = min(tilemap.rows - 1, row + 4)
        maxCol = min(tilemap.cols - 1, col + 4)
        for i in range(minRow, maxRow):
            for j in range(minCol, maxCol):
                if tilemap.tiles[i][j].empty:
                    continue
                rx = tilemap.tiles[i][j].x
                ry = tilemap.tiles[i][j].y
                rw = tilemap.tileWidth
                rh = tilemap.tileHeight
                cx = self.pos.x
                cy = self.pos.y
                cr = self.r
                if circleInRect(cx, cy, cr, rx, ry, rw, rh):
                    return True
        if enemy.dead:
            return False
        dist = distance(self.pos.x, self.pos.y, enemy.centerX, enemy.centerY)
        enemy_r = enemy.w
        if dist <= 100:
            enemy.takeDamage(10)
            return True

        return False
