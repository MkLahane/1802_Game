import pygame
from particle import Particle
import random
import math

class Emitter(object):
    def __init__(self):
        self.particles = []

    def emit(self, p):
        self.particles.append(p);

    def updateParticles(self, dt, anotherEmitter=None):
        for i in range(len(self.particles) - 1, -1, -1):
            p = self.particles[i]
            p.update(dt)
            if p.dead:
                del self.particles[i]

    def renderParticles(self, window, screenX, screenY):
        for p in self.particles:
            p.render(window, screenX, screenY)