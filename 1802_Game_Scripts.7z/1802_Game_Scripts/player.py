from node import *
from bone import *
import math
from bullet import Bullet
from emitter import Emitter
from burstParticles import BurstParticle
import random
from ui import *
class Player(object):
    def __init__(self, hx, hy):
        self.nodeNames = ["hip", "leftFoot", "rightFoot", "leftKnee", "rightKnee",
                          "head", "neck", "leftElbow", "rightElbow", "leftHand", "rightHand"]

        self.boneNames = ["leftThigh", "rightThigh", "back", "leftLeg", "rightLeg",
                          "leftArm", "rightArm", "leftHand", "rightHand", "neck"]
        self.nodes = {}
        self.fixed = False
        self.nodes["hip"] = Node(hx, hy, 5)
        self.nodes["leftKnee"] = Node(hx - 20, hy + 30, 5)
        self.nodes["rightKnee"] = Node(hx + 20, hy + 30, 5)
        self.nodes["neck"] = Node(hx, hy - 40, 5)
        self.nodes["head"] = Node(hx, hy - 70, 5)
        self.nodes["leftFoot"] = Node(hx - 20, hy + 70, 5)
        self.nodes["rightFoot"] = Node(hx + 20, hy + 70, 5)
        self.nodes["leftElbow"] = Node(hx - 20, hy - 30, 5)
        self.nodes["rightElbow"] = Node(hx + 20, hy - 30, 5)
        self.nodes["leftHand"] = Node(hx - 30, hy, 5)
        self.nodes["rightHand"] = Node(hx + 30, hy, 5)
        self.bones = {};
        self.bones["leftThigh"] = Bone(self.nodes["hip"], self.nodes["leftKnee"])
        self.bones["rightThigh"] = Bone(self.nodes["hip"], self.nodes["rightKnee"])
        self.bones["back"] = Bone(self.nodes["neck"], self.nodes["hip"])
        self.bones["leftLeg"] = Bone(self.nodes["leftKnee"], self.nodes["leftFoot"])
        self.bones["rightLeg"] = Bone(self.nodes["rightKnee"], self.nodes["rightFoot"])
        self.bones["neck"] = Bone(self.nodes["head"], self.nodes["neck"])
        self.bones["leftArm"] = Bone(self.nodes["neck"], self.nodes["leftElbow"])
        self.bones["leftHand"] = Bone(self.nodes["leftElbow"], self.nodes["leftHand"])
        self.bones["rightArm"] = Bone(self.nodes["neck"], self.nodes["rightElbow"])
        self.bones["rightHand"] = Bone(self.nodes["rightElbow"], self.nodes["rightHand"])
        self.fixedPos = self.nodes["neck"].pos
        self.bullets = []
        self.canFire = True
        self.timeForFire = 0
        self.fireRate = 1
        self.dead = False
        self.health = 100
        self.healthAlpha = 0
        self.bulletParticlesBurst = Emitter()
        self.headToFootDiff = self.nodes["leftFoot"].pos.y - self.nodes["head"].pos.y
        self.playerHeatlhBar = HealthBar(Vector2(1000, 20), 180, 10)
        self.healthIncrementRate = 2
        self.healthTimer = 0.0
        self.fireSound = pygame.mixer.Sound('external/playerShoot2.wav')
        self.fireSound.set_volume(0.1)
        self.damageSound = pygame.mixer.Sound('external/playerDamage.wav')

    def show(self, window, tilemap):
        self.playerHeatlhBar.show(window)
        if self.dead:
            return

        for boneName in self.bones:
            if boneName == "rightHand" and self.fixed:
                self.bones[boneName].show(window, tilemap.camX, tilemap.camY)
                #self.bones[boneName].specialShow(window, tilemap.camX, tilemap.camY)
            else:
                self.bones[boneName].show(window, tilemap.camX, tilemap.camY)

        for bullet in self.bullets:
            bullet.show(window, tilemap.camX, tilemap.camY)

        self.bulletParticlesBurst.renderParticles(window, tilemap.camX, tilemap.camY)
        pygame.gfxdraw.box(window, (int(0), int(0),
                                    tilemap.camW, tilemap.camH), (0, 0, 0, self.healthAlpha))

    def takeDamage(self, damage):
        self.health -= damage
        if self.health < 0:
            self.health = 0
            self.dead = True
        self.healthAlpha = 200




    def update(self, dt, tilemap, screenX, screenY, screenW, screenH, enemy):
        self.healthTimer += dt
        if self.healthTimer >= self.healthIncrementRate:
            self.healthTimer = 0.0
            self.health += 2
            if self.health > 100:
                self.health = 100
        self.playerHeatlhBar.update(self.health)
        if self.dead:
            return
        self.bulletParticlesBurst.updateParticles(dt)
        for bullet in self.bullets:
            if bullet.hit(enemy, tilemap):
                a = 0
                a = 0
                num_particles = 30
                da = 360 / num_particles
                for i in range(num_particles):
                    self.bulletParticlesBurst.emit(BurstParticle(
                        bullet.pos.x + random.randint(-5, 5), bullet.pos.y + random.randint(-5, 5),
                        random.randint(30, 50), a,
                        (255, 255, 255, 255), random.randint(2, 5), random.uniform(1, 2), onlyAlpha = True
                    ))
                    a += da
                self.bullets.remove(bullet)
        self.healthAlpha -= dt * 100
        if self.healthAlpha < 0:
            self.healthAlpha = 0
        if not self.canFire:
            self.timeForFire += dt
            if self.timeForFire > self.fireRate:
                self.timeForFire = 0.0
                self.canFire = True
        self.fixedPos = self.nodes["neck"].pos
        for bullet in self.bullets:
            bullet.update(dt)
            if bullet.out_of_bounds(screenX, screenY, screenW, screenH):
                self.bullets.remove(bullet)


        if not self.fixed:
            for i in range(5):
                hipNode = self.nodes["hip"]
                leftKnee = self.nodes["leftKnee"]
                rightKnee = self.nodes["rightKnee"]
                leftFoot = self.nodes["leftFoot"]
                rightFoot = self.nodes["rightFoot"]
                headNode = self.nodes["head"]
                ydiffL = leftFoot.pos.y - headNode.pos.y
                ydiffR = rightFoot.pos.y - headNode.pos.y
                ydiff = min(ydiffL, ydiffR)

                ydiffFL = leftFoot.pos.y - leftKnee.pos.y
                ydiffFR = rightFoot.pos.y - rightKnee.pos.y
                if ydiffFL < (self.bones["leftLeg"].ydiff) * 1.0:
                    leftKnee.pos.y -= 2 * dt
                if ydiffFR < (self.bones["rightLeg"].ydiff) * 1.0:
                    rightKnee.pos.y -= 2 * dt
                ydiffLK = leftKnee.pos.y - hipNode.pos.y
                ydiffRK = rightKnee.pos.y - hipNode.pos.y
                if ydiffLK < (self.bones["leftThigh"].ydiff) * 0.1 or ydiffRK < (self.bones["leftThigh"].ydiff) * 1.0:
                    hipNode.pos.y -= 2 * dt

                neckNode = self.nodes["neck"]
                yDiffN = hipNode.pos.y - neckNode.pos.y
                if yDiffN < (self.bones["back"].ydiff) * 1.0:
                    neckNode.pos.y -= 4 * dt
                headNode = self.nodes["head"]
                yDiffH = neckNode.pos.y - headNode.pos.y
                if yDiffH < (self.bones["neck"].ydiff) * 1.0:
                    headNode.pos.y -= 4 * dt

                headNode.update(dt, tilemap)
                hipNode.update(dt, tilemap)
                rightKnee.update(dt, tilemap)
                rightFoot.update(dt, tilemap)
                leftKnee.update(dt, tilemap)
                leftFoot.update(dt, tilemap)

        if not self.fixed:
            for i in range(15):
                for boneName in self.bones:
                    self.bones[boneName].constrain(dt, tilemap)
        if not self.fixed:
            for boneName in self.bones:
                self.bones[boneName].update(dt, tilemap)
            self.addForces(0, 120)


    def calculateEnd(self, start, len, angle):
        ex = math.cos(angle) * len
        ey = math.sin(angle) * len
        end = Vector2(ex, ey)
        end += start
        return end

    def seek(self, tx, ty, start, len):
        target = Vector2(tx, ty)
        dir = target - start
        dir = dir.normalize()
        angle = dir.radians()
        dir *= -len
        start = target + dir
        end = self.calculateEnd(start, len, angle)
        return (start, end)

    def setStart(self, _start, len, _angle):
        start = _start.copy()
        end = self.calculateEnd(start, len, _angle)
        return (start, end)

    def setFixedPos(self, fixedPos):
        self.fixedPos = fixedPos

    def follow(self, mx, my, screenX, screenY):
        if self.dead:
            return
        mx, my = screen_to_world(mx, my, screenX, screenY)
        rightElbow = self.nodes["rightElbow"]
        rightFist = self.nodes["rightHand"]
        rightHand = self.bones["rightHand"]
        neck = self.nodes["neck"]
        rightArm = self.bones["rightArm"]

        neck_pos = neck.pos
        re_pos = rightElbow.pos
        rf_pos = rightFist.pos

        re_pos, rf_pos = self.seek(mx, my, re_pos, rightHand.restingLen)

        neck_pos, re_pos = self.seek(re_pos.x, re_pos.y, neck_pos, rightArm.restingLen)
        dir = (re_pos - neck_pos)
        neck_pos, re_pos = self.setStart(self.fixedPos, rightArm.restingLen, dir.radians())
        dir = (rf_pos - re_pos)
        re_pos, rf_pos = self.setStart(re_pos, rightHand.restingLen, dir.radians())
        neck.pos = neck_pos
        neck.old_pos = neck_pos
        rightElbow.pos = re_pos
        rightElbow.old_pos = re_pos
        rightFist.pos = rf_pos
        rightFist.old_pos = rf_pos

    def move(self, key_pressed):
        if self.dead:
            return
        if key_pressed[pygame.K_a]:
            self.nodes["hip"].applyForce(-300, 0)
        elif key_pressed[pygame.K_d]:
            self.nodes["hip"].applyForce(300, 0)
    def jump(self, tilemap):
        if self.dead:
            return
        leftFoot = self.nodes["leftFoot"]
        rightFoot = self.nodes["rightFoot"]
        isOnGround = False
        for i in range(tilemap.rows):
            for j in range(tilemap.cols):
                if tilemap.tiles[i][j].empty:
                    continue
                rx = tilemap.tiles[i][j].x
                ry = tilemap.tiles[i][j].y
                rw = tilemap.tileWidth
                rh = tilemap.tileHeight
                if (circleInRect(leftFoot.pos.x, leftFoot.pos.y, leftFoot.r * 3, rx, ry, rw, rh) or
                    circleInRect(rightFoot.pos.x, rightFoot.pos.y, rightFoot.r * 3, rx, ry, rw, rh)):
                    isOnGround = True
                    break
            if isOnGround:
                break

        isOnGround = True
        if not isOnGround:
            return
        for node in self.nodeNames:
            self.addForces(0, -100)
    def addForces(self, fx, fy):
        for node in self.nodeNames:
            self.nodes[node].applyForce(fx, fy)

    def shoot(self):
        if self.canFire and not self.dead:
            self.fireSound.play()
            dir = self.nodes["rightHand"].pos - self.nodes["rightElbow"].pos
            self.bullets.append(Bullet(self.nodes["rightHand"].pos, dir.radians_inv(), 10))
            self.canFire = False



