from util import *
from collision import *
from node import *
from bone import *
import random
from rope_enemy_bullet import RopeEnemyBullet
from burstParticles import BurstParticle
from emitter import Emitter
class RopeEnemy(object):
    def __init__(self, x, y):
        self.r = 5
        self.centerX = x
        self.centerY = y
        self.fixedNode = Node(x, y, self.r)
        self.nodes = []
        spacing = 30
        w = 70
        self.nodes.append(Node(x, y, self.r)) #0
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y + spacing, self.r)) #1
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y + spacing, self.r)) #2
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y + spacing, self.r)) #3
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y + spacing, self.r)) #4
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y + spacing, self.r)) #5
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y + spacing, self.r)) #6
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y + spacing, self.r)) #7
        self.nodes.append(Node(x + w, self.nodes[len(self.nodes) - 1].pos.y, self.r)) #8
        self.nodes.append(Node(x + w, self.nodes[len(self.nodes) - 1].pos.y + w, self.r)) #9
        self.nodes.append(Node(x, self.nodes[len(self.nodes) - 1].pos.y, self.r)) #10
        self.bones = []

        for i in range(0, len(self.nodes) - 1):
            self.bones.append(Bone(self.nodes[i], self.nodes[i + 1], stiffness = 0.5))
        self.bones.append(Bone(self.nodes[len(self.nodes) - 1], self.nodes[7]))
        self.bones.append(Bone(self.nodes[7], self.nodes[9]))
        self.bones.append(Bone(self.nodes[len(self.nodes) - 1], self.nodes[8]))
        self.nodes[0].fixed = True
        self.t = 0
        self.moveTime = 0
        self.moveRate = random.uniform(1, 3)
        self.bullets = []
        self.fireSound = pygame.mixer.Sound('external/playerShoot2.wav')
        self.fireSound.set_volume(0.2)
        self.enemyParticlesBurst = Emitter()
    def show(self, window, screenX, screenY):
        self.enemyParticlesBurst.renderParticles(window, screenX, screenY)
        a = self.nodes[7].pos
        b = self.nodes[8].pos
        c = self.nodes[9].pos
        d = self.nodes[10].pos
        ax, ay = world_to_screen(a.x, a.y, screenX, screenY)
        bx, by = world_to_screen(b.x, b.y, screenX, screenY)
        cx, cy = world_to_screen(c.x, c.y, screenX, screenY)
        dx, dy = world_to_screen(d.x, d.y, screenX, screenY)

        rw = abs(a.x - c.x)
        rh = abs(a.y - c.y)
        pygame.draw.circle(window, (0, 0, 0), (int(ax + rw * 0.5), int(ay + rw * 0.5)), 60)
        for bullet in self.bullets:
            bullet.show(window, screenX, screenY)
        for i in range(len(self.bones)):
            bone = self.bones[i]
            if i > 6:
                continue
            bone.show(window, screenX, screenY, color = (0, 0, 0), nodeColor = (0, 0, 0))


    def update(self, dt, player, tilemap):
        for node in self.nodes:
            for nodeName in player.nodeNames:
                playerNode = player.nodes[nodeName]
                dist = distance(node.pos.x, node.pos.y, playerNode.pos.x, playerNode.pos.y)
                if dist <= playerNode.r + node.r:
                    player.takeDamage(1)
                    player.addForces(0, 300)
        self.enemyParticlesBurst.updateParticles(dt)
        for bullet in self.bullets:
            if bullet.hit(player, tilemap):
                self.bullets.remove(bullet)
                a = 0
                num_particles = 30
                da = 360 / num_particles
                for i in range(num_particles):
                    self.enemyParticlesBurst.emit(BurstParticle(
                        bullet.pos.x, bullet.pos.y,
                        random.randint(50, 100), a,
                        (0, 0, 0, 255), random.randint(2, 3), 1
                    ))
                    a += da
        for bullet in self.bullets:
            bullet.update(dt)
            bullet.addForce(Vector2(0, 120))
        self.t += 2 * dt
        self.moveTime += dt
        if self.moveTime >= self.moveRate:
            self.moveTime = 0
            self.fireSound.stop()
            self.fireSound.play()
            self.moveRate = random.uniform(1, 3)
            self.makeMove()
        amp = 200
        self.nodes[0].pos.x = self.centerX + amp * math.sin(self.t)
        for node in self.nodes:
            node.applyForce(0, 80)



        for bone in self.bones:
            bone.update(dt, tilemap)
        for i in range(3):
            for bone in self.bones:
                bone.constrain(dt, tilemap)


    def makeMove(self):
        self.bullets.append(RopeEnemyBullet(self.nodes[len(self.nodes) - 1].pos, Vector2(0, 0), 20))

