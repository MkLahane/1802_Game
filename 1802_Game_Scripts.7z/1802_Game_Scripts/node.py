from vector import *
import pygame
from collision import *
from util import *
class Node(object):
    def __init__(self, x, y, r, friction = 0.99):
        self.pos = Vector2(x, y)
        self.r = r
        self.old_pos = Vector2(x, y)
        self.acc = Vector2(0, 0)
        self.fixed = False
        self.invmass = 1.0
        self.friction = friction
    def show(self, window, screenX, screenY, color = (255, 255, 255, 255)):
        x, y = world_to_screen(self.pos.x, self.pos.y, screenX, screenY)
        #pygame.draw.circle(window, (255, 255, 255), (int(x), int(y)), self.r)
        pygame.gfxdraw.filled_circle(window, int(x), int(y),
                                     int(self.r), color)
    def getVel(self):

        return (self.pos - self.old_pos) * self.friction

    def update(self, dt, tilemap):
        isColliding = False
        if not self.fixed:
            self.checkBounds(tilemap)
            vel = self.getVel()
            self.old_pos = self.pos.copy()
            self.pos.x += vel.x + self.acc.x * dt * dt
            xColliding = self.collision(tilemap, 'x')
            self.pos.y += vel.y + self.acc.y * dt * dt
            yColliding = self.collision(tilemap, 'y')
            isColliding = xColliding or yColliding
            self.acc *= 0
        return isColliding

    def collision(self, tilemap, movement):
        vel = self.getVel()
        bounciness = 0.9
        row = int(self.pos.y // tilemap.tileHeight)
        col = int(self.pos.x // tilemap.tileWidth)
        minRow = max(0, row - 3)
        minCol = max(0, col - 3)
        maxRow = min(tilemap.rows - 1, row + 4)
        maxCol = min(tilemap.cols - 1, col + 4)
        isAnyNodeColliding = False
        for i in range(minRow, maxRow):
            for j in range(minCol, maxCol):
                if tilemap.tiles[i][j].empty:
                    continue
                rx = tilemap.tiles[i][j].x
                ry = tilemap.tiles[i][j].y
                rw = tilemap.tileWidth
                rh = tilemap.tileHeight
                cx = self.pos.x
                cy = self.pos.y
                cr = self.r
                if circleInRect(cx, cy, cr, rx, ry, rw, rh):
                    isAnyNodeColliding = True
                    if movement == 'x':
                        self.pos.x = self.old_pos.x
                        self.old_pos.x = vel.x * bounciness + self.pos.x
                    else:
                        self.pos.y = self.old_pos.y
                        self.old_pos.y = vel.y * bounciness + self.pos.y
        return isAnyNodeColliding

    def checkBounds(self, tilemap):
        w = 1200
        h = 800

        vel = self.getVel()
        bounciness = 0.1


        if self.pos.x < self.r or self.pos.x > tilemap.tileWorldEndX - self.r:
            self.pos.x = self.old_pos.x
            self.old_pos.x = self.pos.x + vel.x * bounciness
        if self.pos.y < self.r or self.pos.y > h - self.r:
            self.pos.y = self.old_pos.y
            self.old_pos.y = self.pos.y + vel.y * bounciness


    def applyForce(self, fx, fy):
        self.acc.x = self.acc.x + fx
        self.acc.y = self.acc.y + fy

    def flipVel(self):
        temp = self.old_pos.copy()
        self.old_pos = self.pos + self.getVel()
