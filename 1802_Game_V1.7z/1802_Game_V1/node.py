from vector import *
import pygame
class Node(object):
    def __init__(self, x, y, r):
        self.pos = Vector2(x, y)
        self.r = r
        self.old_pos = Vector2(x, y)
        self.acc = Vector2(0, 0)

    def show(self, window):
        pygame.draw.circle(window, (0, 255, 0), (int(self.pos.x), int(self.pos.y)), self.r)

    def getVel(self):
        return (self.pos - self.old_pos)
    def update(self, dt):
        self.checkBounds()
        vel = self.getVel()
        self.old_pos = self.pos.copy()
        self.pos += vel + self.acc * dt * dt
        self.acc *= 0

    def checkBounds(self):
        w = 1200
        h = 800

        vel = self.getVel()
        bounciness = 0.9
        # bounce = False
        # if ((self.pos.x < self.r) or (self.pos.y > h - self.r) or
        #     (self.pos.x > w - self.r) or (self.pos.y < self.r)):
        #     bounce = True

        if self.pos.x < self.r or self.pos.x > w - self.r:
            self.pos.x = self.old_pos.x
            self.old_pos.x = self.pos.x + vel.x * bounciness
        if self.pos.y < self.r or self.pos.y > h - self.r:
            self.pos.y = self.old_pos.y
            self.old_pos.y = self.pos.y + vel.y * bounciness


    def applyForce(self, fx, fy):
        self.acc.x = self.acc.x + fx
        self.acc.y = self.acc.y + fy

    def flipVel(self):
        temp = self.old_pos.copy()
        self.old_pos = self.pos + self.getVel()
