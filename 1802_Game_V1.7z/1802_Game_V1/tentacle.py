from builtins import int

from segment import *
class Tentacle(object):
    def __init__(self, startPos, angle, len, howMany):
        self.segments = []
        for i in range(0, howMany):
            sw = i
            if i == 0:
                self.segments.append(Segment(startPos, angle, len, sw))
            else:
                self.segments.append(Segment(self.segments[i - 1].end, angle, len, sw))

    def lastFollow(self, lx, ly):
        self.segments[len(self.segments) - 1].follow(lx, ly)

    def follow(self):
        for i in range(len(self.segments) - 2, -1, -1):
            nextx = self.segments[i + 1].start.x
            nexty = self.segments[i + 1].start.y

            self.segments[i].follow(nextx, nexty)

    def show(self, window):
        for segment in self.segments:
            segment.show(window)

    def fix(self, fx, fy):
        self.segments[0].setStart(Vector2(fx, fy))
        for i in range(1, len(self.segments)):
            self.segments[i].setStart(self.segments[i - 1].end)

