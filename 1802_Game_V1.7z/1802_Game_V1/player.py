from node import *
from bone import *
class Player(object):
    def __init__(self, hx, hy):
        self.nodeNames = ["hip", "leftFoot", "rightFoot", "leftKnee", "rightKnee",
                          "head", "neck", "leftElbow", "rightElbow", "leftHand", "rightHand"]

        self.boneNames = ["leftThigh", "rightThigh", "back", "leftLeg", "rightLeg",
                          "leftArm", "rightArm", "leftHand", "rightHand", "neck"]
        self.nodes = {}
        self.nodes["hip"] = Node(hx, hy, 5)
        self.nodes["leftKnee"] = Node(hx - 20, hy + 30, 5)
        self.nodes["rightKnee"] = Node(hx + 20, hy + 30, 5)
        self.nodes["neck"] = Node(hx, hy - 50, 5)
        self.nodes["head"] = Node(hx, hy - 80, 5)
        self.nodes["leftFoot"] = Node(hx - 20, hy + 70, 5)
        self.nodes["rightFoot"] = Node(hx + 20, hy + 70, 5)
        self.nodes["leftElbow"] = Node(hx - 20, hy - 30, 5)
        self.nodes["rightElbow"] = Node(hx + 20, hy - 30, 5)
        self.nodes["leftHand"] = Node(hx - 30, hy, 5)
        self.nodes["rightHand"] = Node(hx + 30, hy, 5)
        self.bones = {};
        self.bones["leftThigh"] = Bone(self.nodes["hip"], self.nodes["leftKnee"])
        self.bones["rightThigh"] = Bone(self.nodes["hip"], self.nodes["rightKnee"])
        self.bones["back"] = Bone(self.nodes["hip"], self.nodes["neck"])
        self.bones["leftLeg"] = Bone(self.nodes["leftKnee"], self.nodes["leftFoot"])
        self.bones["rightLeg"] = Bone(self.nodes["rightKnee"], self.nodes["rightFoot"])
        self.bones["neck"] = Bone(self.nodes["neck"], self.nodes["head"])
        self.bones["leftArm"] = Bone(self.nodes["neck"], self.nodes["leftElbow"])
        self.bones["leftHand"] = Bone(self.nodes["leftElbow"], self.nodes["leftHand"])
        self.bones["rightArm"] = Bone(self.nodes["neck"], self.nodes["rightElbow"])
        self.bones["rightHand"] = Bone(self.nodes["rightElbow"], self.nodes["rightHand"])

    def show(self, window):
        for boneName in self.bones:
            self.bones[boneName].show(window)


    def update(self, dt):
        for boneName in self.bones:
            self.bones[boneName].update(dt)
        self.addForces(0, 80)

    def addForces(self, fx, fy):
        for node in self.nodeNames:
            self.nodes[node].applyForce(fx, fy)




