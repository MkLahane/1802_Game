import tilemap
import pygame
from player import Player
from enemy import Enemy
pygame.init()
win_w = 1200
win_h = 800
tilemap = tilemap.Tilemap("external/tilemapData.txt", 0, 0, win_w, win_h)
window = pygame.display.set_mode((win_w, win_h))

clock = pygame.time.Clock()
player = Player(200, 100)
enemy = Enemy(8, 800, 300)
while True:
    window.fill((0, 0, 0))
    dt = clock.tick() / 1000
    #clock.tick(60)
    event = pygame.event.poll()
    if event.type == pygame.QUIT:
        break
    elif event.type == pygame.KEYDOWN:
        if event.key == pygame.K_ESCAPE:
            break

    tilemap.show(window)
    player.show(window)
    tilemap.collision(player)
    player.update(dt)
    enemy.update(dt)
    enemy.show(window)

    pygame.display.flip()

pygame.quit()