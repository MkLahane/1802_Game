#Makarand Lahane
#ETGG 1803
#02/06/2020
import math
import matrix 
class Vector(object):
    def __init__(self, *args):
        '''
        Constructor for initializing the data
        :param args:
        takes in args which is a sequence of data
        '''
        self.data = []
        for arg in args:
            if isinstance(arg, str):
                raise TypeError
            self.data.append(float(arg))
        self.dim = len(self.data)
        if self.dim == 2:
            self.__class__ = Vector2
        elif self.dim == 3:
            self.__class__ = Vector3 



    def __str__(self):
        '''
        param: no parameters
        just prints all the components of this vector instance
        ''' 
        s = "<Vector" + str(self.dim) + ": "
        for i in range(self.dim):
            if i == len(self.data) - 1:
                s += str(self.data[i])+""
            else:
                s += str(self.data[i])+", "
        s += ">"
        return s
    def __getitem__(self, index):
        '''
        :param index: an integer index
        :return: returns the value stored by self.data at that index
        '''
        return self.data[index]

    def __add__(self, other):
        '''
        :param other: another vector for addition
        :return: returns a new vector as a result of the sum of the given 2 vectors
        '''
        if not isinstance(other, Vector) and not isinstance(other, Vector2):
            raise TypeError("Not a vector")
        if other.dim != self.dim:
            raise ValueError("Dimensions should match")
        newVecData = [] 
        for i in range(self.dim):
            newVecData.append(self.data[i] + other.data[i])

        return Vector(*newVecData)
    def __sub__(self, other):
        '''
        :param other: another vector for addition
        :return: returns a new vector as a result of the subtraction  of the given 2 vectors
        '''
        return self + (-other) 

    def __mul__(self, other):
        '''
        :param other: takes in a scalar value an integer or float and scales the vector accordingly
        :return: returns a new scaled vector
        '''
        
        if isinstance(other, int) or isinstance(other, float):
            temp = [] 
            for d in self.data:
                temp.append(d * other)
            
            return Vector(*temp) 
        return NotImplemented

    def __rmul__(self, other):
        '''
        reverse multiplication
        :param other: takes in a scalar value an integer or float and scales the vector accordingly
        :return: returns a new scaled vector
        '''
           
        return self * other  

    def __neg__(self):
        '''
        :return: returns the inverse of the vector
        '''
        return self * -1

    def __len__(self):
        '''
        returns: the dimensions of this vector
        '''
        return  self.dim 

    def __setitem__(self, index, value):
        '''
        :param index: an integer index
        :param value: new value which is an integer or float for the value at that index
        :return: nothing
        '''
        if isinstance(value, str):
            raise TypeError("Invalid type") 
        self.data[index] = value

    def __eq__(self, other):
        '''
        param other: another vector to check the equality of this and the other vector
        returns: true if they are equal
        ''' 
        if not isinstance(other, Vector) and not isinstance(other, Vector2):
            raise TypeError("Not a vector")
        if other.dim != self.dim:
            raise ValueError("Dimensions should be equal")
        for i in range(self.dim):
            if other.data[i] != self.data[i]:
                return False
        return True

    def __ne__(self, other):
        '''
        param other: another vector to check the equality of this and the other vector
        returns: true if they are not equal
        '''
        return not self == other
    
    def copy(self):
        '''
        :return: returns a deep copy of this vector
        '''
        return Vector(*self.data)

    def __truediv__(self, other):
        '''
        :param other: takes in a scalar value an integer or float and scales the vector accordingly
        :return: returns a new scaled vector
        '''
        if other == 0:
                raise ValueError("Cannot divide by zero") 

        return self * (1 / other) 

    def norm(self, p):
        '''
        :param p : should be a positive integer to raise every element by p and raise the sum of it by 1/p
        :returns : pth norm of the vector
        '''
        if (isinstance(p, str)):
            raise TypeError("Invalid type")

        if p <= 0:
            raise ValueError("Cannot be negative or zero")
        
        s = 0
        for value in self.data:
            s += abs(value) ** p

        s = s ** (1 / p)
        return s

    def mag(self):
        '''
        :returns : the magnitude of the vector
        '''
        return self.norm(2)

    def mag_squared(self):
        '''
        :returns : the magnitude squared of the vector
        '''
        return self.norm(2) ** 2

    def normalize(self):
        '''
        :returns : the normalized version of the vector
        '''
        return self.copy() / self.mag() 

    def is_zero(self):
        '''
        :returns : true if the vector is zero vector
        '''
        is_zero = True
        for d in self.data:
            if d != 0:
                is_zero = False

        return is_zero

    def i(self):
        '''
        :returns : a tuple of integers of the components of the vector
        '''
        return tuple(self.data[0:self.dim]) 

class Vector2(Vector):
    def __init__(self, x, y):
        '''
        :param x: x component of vector2
        :param y: y component of vector2
        '''
        super().__init__(x,  y)

    @property 
    def x(self):
        '''
        :param: vector instance
        :return: returns the x component of the vector
        '''
        return self.data[0]
    @x.setter 
    def x(self, value):
        '''
        :param value: new value which should be a float or int for the x component of this vector
        '''
        if (isinstance(value, str)):
            raise TypeError("Invalid type")
        self.data[0] = value

    @property 
    def y(self):
        '''
        :param: vector instance
        :return: returns the y component of the vector
        '''
        return self.data[1]

    @y.setter 
    def y(self, value):
        '''
        :param value: new value which should be a float or int for the y component of this vector
        '''
        if (isinstance(value, str)):
            raise TypeError("Invalid type")
        self.data[1] = value

    def degrees(self):
        '''
        :returns: the direction of this vector in degrees 
        '''
        return math.degrees(math.atan2(self.y, self.x))
    def degrees_inv(self):
        '''
        :returns: the direction of this vector in degrees with the y value inverted for pygame 
        '''
        return math.degrees(math.atan2(-self.y, self.x))

    def radians(self):
        '''
        :returns: the direction of this vector in radians 
        '''
        return math.atan2(self.y, self.x)
    
    def radians_inv(self):
        '''
        :returns: the direction of this vector in radians with the y value inverted for pygame 
        '''
        return math.atan2(-self.y, self.x)

    def perpendicular(self):
        '''
        :returns: a perpendicular vector to this vector
        '''
        return Vector2(-self.y, self.x)
    
         

class Vector3(Vector):
    def __init__(self, x, y, z):
        '''
        :param x: x component of vector3
        :param y: y component of vector3
        :param z: z component of vector3
        '''
        super().__init__(x, y, z)
        
    @property 
    def x(self):
        '''
        :param: vector instance
        :return: returns the x component of the vector
        '''
        return self.data[0]
    @x.setter 
    def x(self, value):
        '''
        :param value: new value which should be a float or int for the x component of this vector
        '''
        if (isinstance(value, str)):
            raise TypeError("Invalid type")
        self.data[0] = value 

    @property 
    def y(self):
        '''
        :param: vector instance
        :return: returns the y component of the vector
        '''
        return self.data[1]
    @y.setter 
    def y(self, value):
        '''
        :param value: new value which should be a float or int for the y component of this vector
        '''
        if (isinstance(value, str)):
            raise TypeError("Invalid type")
        self.data[1] = value 

    @property 
    def z(self):
        '''
        :param: vector instance
        :return: returns the z component of the vector
        '''
        return self.data[2]

    @z.setter 
    def z(self, value):
        '''
        :param value: new value which should be a float or int for the z component of this vector
        '''
        if (isinstance(value, str)):
            raise TypeError("Invalid type")
        self.data[2] = value






def dot(a, b):
    '''
    :param a, b : 2 vectors for calculating the dot product 
    :returns : the dot product of the 2 vectors
    '''
    if not isinstance(b, Vector) or not isinstance(a, Vector):
        raise TypeError("Invalid type")

    if a.dim != b.dim:
        raise ValueError("Dimensions of the 2 vectors should be equal")
                             
    s = 0
    for i in range(a.dim):
        s += a[i] * b[i]

    return s



def cross(a, b):
    '''
    :param a, b : 2 vectors for calculating the cross product
    :returns : the cross product  a and b
    '''
    if not isinstance(a, Vector3) or not isinstance(b, Vector3):
        raise TypeError("Invalid  Type")

    if a.dim != b.dim:
        raise ValueError("Dimensions of the 2 vectors should be equal")

    x = a.y * b.z - a.z * b.y
    y = -(a.x * b.z - a.z * b.x)
    z = a.x * b.y - a.y * b.x

    return Vector3(x, y, z)




def polar_to_Vector2(angle, radius, mode = "degrees", negate = True):
    '''
    :param angle : can be degrees or radians, and defines the direction of the vector 
    :param radius : defines the length of the vector
    :param mode : default to degrees and can also be set to radians, defines the mode in which the angle is provided
    :param negate: defaulted  to True, defines the negation of y value for pygame
    '''
    if mode != "degrees" and mode != "radians":
        raise ValueError("Enter radians or degrees")

    rad_angle = angle
    if mode == "degrees":
        rad_angle = math.radians(rad_angle)

    x = radius * math.cos(rad_angle)
    y = radius * math.sin(rad_angle)

    if negate:
        y *= -1

    return Vector2(x, y) 

    


    
