import pygame
class Bone(object):
    def __init__(self, startNode, endNode):
        self.startNode = startNode
        self.endNode = endNode

    def show(self, window):
        s = self.startNode.pos
        e = self.endNode.pos
        #pygame.draw.line(window, (0, 0, 0), (int(s.x), int(s.y)), (int(e.x), int(e.y)), 4)
        self.startNode.show(window)
        self.endNode.show(window)

    def update(self, dt):
        self.startNode.update(dt)
        self.endNode.update(dt)

