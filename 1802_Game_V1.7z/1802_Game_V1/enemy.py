from tentacle import *
from vector import *
import math
import random
class Enemy(object):
    def __init__(self, numTentacles, sX, sY):
        self.numTentacles = numTentacles
        self.tentacles = []
        self.numSegments = 15
        a = 0
        da = 360 / self.numTentacles
        for i in range(self.numTentacles):
            self.tentacles.append(Tentacle(Vector2(sX, sY), math.radians(a), 15, self.numSegments))
            a += da
        self.enemyParticles = []
        self.centerX = sX
        self.centerY = sY
        self.w = 500
        self.h = 500
        for i in range(self.numTentacles):
            self.enemyParticles.append(EnemyParticle(random.uniform(self.centerX - self.w * 0.5 + 10, self.centerX + self.w * 0.5 - 10),
                                                    random.uniform(self.centerY - self.h * 0.5 + 10, self.centerY + self.h * 0.5 - 10),
                                                    self.centerX, self.centerY, self.w, self.h))


    def show(self, window):
        for tentacle in self.tentacles:
            tentacle.show(window)
        for enemyParticle in self.enemyParticles:
            enemyParticle.show(window)
        rx = int(self.centerX - self.w * 0.5)
        ry = int(self.centerY - self.h * 0.5)
        #pygame.draw.rect(window, (0, 0, 0), (int(rx), int(ry), self.w, self.h), 2)

    def update(self, dt):
        for enemyParticle in self.enemyParticles:
            enemyParticle.update(dt)
            enemyParticle.checkBounds()
        for i in range(len(self.tentacles)):
            tentacle = self.tentacles[i]
            tentacle.lastFollow(self.enemyParticles[i].pos.x, self.enemyParticles[i].pos.y)
            tentacle.follow()
            tentacle.fix(self.centerX, self.centerY)


class EnemyParticle(object):
    def __init__(self, sx, sy, centerX, centerY, w, h):
        self.pos = Vector2(sx, sy)
        self.vel = polar_to_Vector2(random.randint(0, 360), 1) *  300
        self.acc = Vector2(0, 0)
        self.r = 10
        self.w =  w
        self.h = h
        self.centerX = centerX
        self.centerY = centerY

    def show(self, window):
        pygame.draw.circle(window, (100, 100, 100), (int(self.pos.x), int(self.pos.y)), self.r)

    def update(self, dt):
        self.vel += self.acc * dt
        self.pos += self.vel * dt
        self.acc *= 0
    def checkBounds(self):
        if self.pos.x < (self.centerX - self.w * 0.5) + self.r:
            self.pos.x = (self.centerX - self.w * 0.5) + self.r
            self.vel.x *= -1
        elif self.pos.x > (self.centerX + self.w * 0.5) - self.r:
            self.pos.x = (self.centerX + self.w * 0.5) - self.r
            self.vel.x *= -1
        if self.pos.y < (self.centerY - self.h * 0.5) + self.r:
            self.pos.y = (self.centerY - self.h * 0.5) + self.r
            self.vel.y *= -1
        elif self.pos.y > (self.centerY + self.h * 0.5) - self.r:
            self.pos.y = (self.centerY + self.h * 0.5) - self.r
            self.vel.y *= -1

