from vector import *
import pygame
import math
class Segment(object):
    def __init__(self, start, angle, len, weight):
        self.start = start.copy()
        self.angle = angle
        self.len = len
        self.end = Vector2(0, 0)
        self.calculateEnd()
        self.weight = weight


    def show(self, window):
        sx = self.start.x
        sy = self.start.y
        ex = self.end.x
        ey = self.end.y
        pygame.draw.line(window, (0, 0, 0), (int(sx), int(sy)), (int(ex), int(ey)), self.weight)

    def calculateEnd(self):
        ex = math.cos(self.angle) * self.len
        ey = math.sin(self.angle) * self.len
        self.end.x = ex
        self.end.y = ey
        self.end += self.start

    def follow(self, tx, ty):
        target = Vector2(tx, ty)
        dir = target - self.start
        dir = dir.normalize()
        self.angle = dir.radians()
        dir *= -self.len
        self.start = target + dir
        self.calculateEnd()


    def setStart(self, _start):
        self.start = _start.copy()
        self.calculateEnd()