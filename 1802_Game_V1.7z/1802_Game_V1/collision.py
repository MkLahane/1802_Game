def circleInRect(cx, cy, r, rx, ry, w, h):
    edgeX = cx
    edgeY = cy
    collisionData = {}
    collisionData["edge"] = None
    if cy < ry: #top edge
        edgeY = ry
        collisionData["edge"] = "top"
    elif cy > ry + h: #bottom edge
        edgeY = ry + h
        collisionData["edge"] = "bottom"
    if cx < rx: #left edge
        edgeX = rx
        collisionData["edge"] = "left"
    elif cx > rx + w: #right edge
        edgeX = rx + w
        collisionData["edge"] = "right"

    distFromEdge = distance(cx, cy, edgeX, edgeY)
    if distFromEdge <= r:
        collisionData["collided"] = True
    else:
        collisionData["collided"] = False

    return collisionData


def distance(x1, y1, x2, y2):
    xdiff = x2 - x1
    ydiff = y2 - y1
    return (xdiff ** 2 + ydiff ** 2) ** 0.5