import pygame
from collision import *
class Tilemap(object):
    def __init__(self, tilemapFileName, camX, camY, camW, camH):
        self.tilemapFileName = tilemapFileName

        f = open(self.tilemapFileName, 'r')
        tilemapFileLines = f.readlines()
        f.close()

        self.rows = int(tilemapFileLines[1].split(':')[1])
        self.cols = int(tilemapFileLines[2].split(':')[1])
        self.tileWidth = float(tilemapFileLines[3].split(':')[1])
        self.tileHeight = float(tilemapFileLines[4].split(':')[1])
        self.tiles = [None] * self.rows
        for i in range(self.rows):
            self.tiles[i] = [None] * self.cols

        r = 0
        c = 0
        for i in range(5, len(tilemapFileLines)):
            empty = False
            tileData = tilemapFileLines[i]
            tileDataImg = tileData.split(";")[1]
            x = c * self.tileWidth
            y = r * self.tileHeight
            tileDataImg = tileDataImg[0: len(tileDataImg) - 1]
            if tileDataImg == "background.png":
                empty = True

            self.tiles[r][c] = Tile(pygame.image.load('external/' + tileDataImg), x, y, self.tileWidth, self.tileHeight, empty)
            c += 1
            if c == self.cols:
                r += 1
                c = 0
        self.camX = camX
        self.camY = camY
        self.camW = camW
        self.camH = camH


    def getMinMaxRowCol(self):
        minRow = int(self.camY / self.tileHeight)
        if minRow < 0:
            minRow = 0
        minCol = int(self.camY / self.tileWidth)
        if minCol < 0:
            minCol = 0
        maxRow = int((self.camY + self.camH) / self.tileHeight)
        if maxRow >= self.rows:
            maxRow = self.rows - 1
        maxCol = int((self.camX + self.camW) / self.tileWidth)
        if maxCol >= self.cols:
            maxCol = self.cols - 1
        return (minRow, minCol, maxRow, maxCol)

    def show(self, window):
        minRow, minCol, maxRow, maxCol = self.getMinMaxRowCol()

        for i in range(minRow, maxRow + 1):
            for j in range(minCol, maxCol + 1):
                self.tiles[i][j].show(self.camX, self.camY, window)

    def collision(self, player):
        nodes = []
        for node in player.nodeNames:
            nodes.append(player.nodes[node])

        for node in nodes:
            for i in range(self.rows):
                for j in range(self.cols):
                    if not self.tiles[i][j].empty:
                        cx = node.pos.x
                        cy = node.pos.y
                        rx = self.tiles[i][j].x
                        ry = self.tiles[i][j].y
                        rw = self.tileWidth
                        rh = self.tileHeight
                        cr = node.r
                        collisionData = circleInRect(cx, cy, cr, rx, ry, rw, rh)
                        if collisionData["collided"]:
                            vel = node.getVel()
                            edgeData = collisionData["edge"]
                            bounciness = 1.0
                            print(edgeData)
                            if edgeData == "left" or edgeData == "right":
                                if edgeData == "left":
                                    node.pos.x = self.tiles[i][j].x - node.r
                                else:
                                    node.pos.x = self.tiles[i][j].x + self.tileWidth + node.r
                                #node.pos.x = node.old_pos.x
                                node.old_pos.x = node.pos.x + vel.x * bounciness
                            elif edgeData == "top" or edgeData == "bottom":
                                if edgeData == "top":
                                    node.pos.y = self.tiles[i][j].y - node.r
                                else:
                                    node.pos.y = self.tiles[i][j].y + self.tileHeight + node.r
                                #node.pos.y = node.old_pos.y
                                node.old_pos.y = node.pos.y + vel.y * bounciness








class Tile(object):
    def __init__(self, tileImg, x, y, w, h, empty):
        self.x = x
        self.y = y
        self.w = w
        self.h = h
        self.tileImg = tileImg
        self.empty = empty

    def show(self, screenX, screenY, window):
        self.x, self.y = worldToScreen(self.x, self.y, screenX, screenY)
        window.blit(self.tileImg, (self.x, self.y, self.w, self.h))


def worldToScreen(wx, wy, screenX, screenY):
    return (wx - screenX, wy - screenY)

